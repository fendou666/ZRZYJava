package o20170308Thread;

public class In2Passenger {
	private String name;

	public In2Passenger(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void buyTicket(In2TrainTicket ticket) {
		System.out.println("�˿�" + name +"������Ʊ����ϢΪ��" +ticket);
		Thread t = new Thread(new In2BuyTicketThread(this, ticket));
		t.start();
	}
	
	public void returnTicket(In2TrainTicket ticket) {
		System.out.println("�˿�" + name +"������Ʊ����ϢΪ��" +ticket);
		Thread t = new Thread(new In2ReturnTicketThread(this, ticket));
		t.start();
	}
	
	public String toString() {
		return "�˿�[����=" +  name + "]";
	}
	
}
